public enum HuLuWaColour {
    RED, ORANGE, YELLOW, GREEN, CYAN, BLUE, PURPLE;
}
